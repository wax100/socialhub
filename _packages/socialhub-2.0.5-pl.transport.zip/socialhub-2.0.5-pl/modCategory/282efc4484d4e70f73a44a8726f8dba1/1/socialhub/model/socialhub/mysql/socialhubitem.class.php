<?php
require_once(dirname(dirname(__FILE__)) . '/socialhubitem.class.php');
class SocialHubItem_mysql extends SocialHubItem {}